import '@testing-library/jest-dom'
import { cleanup } from '@testing-library/react'
import { afterEach } from 'vitest'

// Cleanup after each test
afterEach(() => {
  cleanup()
})

// Essential browser API mocks for test environment only
// These are NOT app features - just testing infrastructure
globalThis.ResizeObserver = class ResizeObserver {
  observe() {}
  unobserve() {}
  disconnect() {}
}

Object.defineProperty(window, 'matchMedia', {
  writable: true,
  value: (query: string) => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: () => {},
    removeListener: () => {},
    addEventListener: () => {},
    removeEventListener: () => {},
    dispatchEvent: () => {},
  }),
})

globalThis.IntersectionObserver = class IntersectionObserver {
  observe() {}
  unobserve() {}
  disconnect() {}
}

// Canvas context for image handling tests
Object.defineProperty(HTMLCanvasElement.prototype, 'getContext', {
  value: () => ({
    drawImage: () => {},
    getImageData: () => ({ data: new Uint8ClampedArray(4) }),
    putImageData: () => {},
    createImageData: () => ({ data: new Uint8ClampedArray(4) }),
    setTransform: () => {},
    drawFocusIfNeeded: () => {},
    createLinearGradient: () => ({ addColorStop: () => {} }),
    createRadialGradient: () => ({ addColorStop: () => {} }),
  }),
})

// File handling APIs
global.URL.createObjectURL = () => 'mocked-url'
global.URL.revokeObjectURL = () => {}

global.File = class File {
  size = 1024
  type = 'text/plain'
  constructor(public data: any[], public name: string, public options?: any) {}
} as any

global.Blob = class Blob {
  size = 1024
  type = 'text/plain'
  constructor(public data: any[], public options?: any) {}
} as any

// Drag and drop APIs
global.DataTransfer = class DataTransfer {
  items: DataTransferItem[] = []
  files: File[] = []
  setData(format: string, data: string) {}
  getData(format: string): string { return '' }
  clearData(format?: string) {}
  setDragImage(image: Element, x: number, y: number) {}
}

global.DragEvent = class DragEvent extends Event {
  constructor(type: string, eventInitDict?: DragEventInit) {
    super(type, eventInitDict)
    this.dataTransfer = eventInitDict?.dataTransfer || new DataTransfer()
  }
  dataTransfer: DataTransfer
} as any

// Clipboard API for paste functionality
global.ClipboardEvent = class ClipboardEvent extends Event {
  constructor(type: string, eventInitDict?: ClipboardEventInit) {
    super(type, eventInitDict)
    this.clipboardData = eventInitDict?.clipboardData || new DataTransfer()
  }
  clipboardData: DataTransfer
} as any

