#!/bin/bash

# 🛡️ BULLETPROOF DEV SERVER LAUNCHER - Marc's Epic Style Template
# Copy this to any project and customize the theme/colors
# Built-in fork bomb prevention and anti-duplication

set -euo pipefail

# ═══════════════════════════════════════════════════════════
# 🎨 PROJECT CONFIGURATION (CUSTOMIZE THIS SECTION)
# ═══════════════════════════════════════════════════════════

PROJECT_NAME="${PWD##*/}"
PROJECT_TITLE="🚀 $(echo "${PROJECT_NAME}" | tr '[:lower:]' '[:upper:]') 🚀"  # Auto-uppercase
VERSION="v1.0.0"
THEME="EPIC"  # Options: EPIC, DNA, GAMING, MINIMAL, CUSTOM

# ═══════════════════════════════════════════════════════════
# 🌈 EPIC COLOR PALETTES (MARC'S SIGNATURE STYLE)
# ═══════════════════════════════════════════════════════════

# Theme: EPIC (Default)
EPIC_PRIMARY='\033[38;5;51m'      # Electric cyan
EPIC_SECONDARY='\033[38;5;129m'   # Royal purple
EPIC_SUCCESS='\033[38;5;46m'      # Bright green
EPIC_WARNING='\033[38;5;220m'     # Golden yellow
EPIC_ERROR='\033[38;5;196m'       # Error red
EPIC_INFO='\033[38;5;39m'         # Electric blue

# Theme: DNA (Gene projects)
DNA_GREEN='\033[38;5;46m'
DNA_BLUE='\033[38;5;39m'
DNA_PURPLE='\033[38;5;129m'
DNA_GOLD='\033[38;5;220m'

# Theme: GAMING (Game projects)
GAME_NEON='\033[38;5;51m'
GAME_PURPLE='\033[38;5;93m'
GAME_GOLD='\033[38;5;214m'
GAME_RED='\033[38;5;196m'

# Common colors
BOLD='\033[1m'
UNDERLINE='\033[4m'
NC='\033[0m'
BG_DARK='\033[48;5;233m'

# Set active palette based on theme
case "$THEME" in
    "DNA")
        PRIMARY=$DNA_GREEN; SECONDARY=$DNA_PURPLE; SUCCESS=$DNA_GREEN
        WARNING=$DNA_GOLD; ERROR=$DNA_GOLD; INFO=$DNA_BLUE ;;
    "GAMING")
        PRIMARY=$GAME_NEON; SECONDARY=$GAME_PURPLE; SUCCESS=$GAME_NEON
        WARNING=$GAME_GOLD; ERROR=$GAME_RED; INFO=$GAME_NEON ;;
    *)
        PRIMARY=$EPIC_PRIMARY; SECONDARY=$EPIC_SECONDARY; SUCCESS=$EPIC_SUCCESS
        WARNING=$EPIC_WARNING; ERROR=$EPIC_ERROR; INFO=$EPIC_INFO ;;
esac

# ═══════════════════════════════════════════════════════════
# 🎭 MARC'S SIGNATURE HELPER FUNCTIONS
# ═══════════════════════════════════════════════════════════

print_epic_banner() {
    echo -e "${PRIMARY}${BOLD}"
    echo "╔═══════════════════════════════════════════════════════════════╗"
    echo "║                    ${PROJECT_TITLE}                    ║"
    echo "║                   ${VERSION} - Ultra Dev Launcher${NC}${PRIMARY}${BOLD}              ║"
    echo "║                  🛡️ Fork Bomb Protected 🛡️                   ║"
    echo "╚═══════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

print_header() {
    echo -e "\n${SECONDARY}═══════════════════════════════════════════${NC}"
    echo -e "${BOLD}${PRIMARY}$1${NC}"
    echo -e "${SECONDARY}═══════════════════════════════════════════${NC}"
}

print_success() { echo -e "${SUCCESS}✅ $1${NC}"; }
print_warning() { echo -e "${WARNING}⚠️  $1${NC}"; }
print_error() { echo -e "${ERROR}❌ $1${NC}"; }
print_info() { echo -e "${INFO}ℹ️  $1${NC}"; }

# Epic startup messages (Marc's style)
EPIC_MESSAGES=(
    "🚀 Launching into the development stratosphere..."
    "⚡ Electrifying your coding neurons..."
    "🎯 Targeting maximum productivity levels..."
    "🌟 Unleashing your inner code wizard..."
    "🔥 Igniting the engines of pure awesomeness..."
    "💫 Weaving magic into your codebase..."
    "🎪 Welcome to the greatest dev show on earth..."
)

random_epic_message() {
    echo "${EPIC_MESSAGES[$((RANDOM % ${#EPIC_MESSAGES[@]}))]}"
}

# Open browser after a short delay (allows server to start)
open_browser() {
    local port="${1:-$DEFAULT_PORT}"
    local url="http://localhost:$port"
    
    if [[ "$AUTO_OPEN_BROWSER" == "true" ]]; then
        print_info "🌍 Opening $url in browser..."
        # Background process to wait and open browser
        (
            sleep 3  # Wait for server to start
            if command -v open >/dev/null 2>&1; then
                open "$url" 2>/dev/null || true
            elif command -v xdg-open >/dev/null 2>&1; then
                xdg-open "$url" 2>/dev/null || true
            elif command -v chrome >/dev/null 2>&1; then
                chrome "$url" 2>/dev/null || true
            elif command -v firefox >/dev/null 2>&1; then
                firefox "$url" 2>/dev/null || true
            fi
        ) &
    fi
}

# ═══════════════════════════════════════════════════════════
# 🛡️ BULLETPROOF SAFETY MECHANISMS (DO NOT MODIFY)
# ═══════════════════════════════════════════════════════════

# Prevent script recursion/loops
if [[ "${SCRIPT_RECURSIVE_GUARD:-}" == "true" ]]; then
    echo "❌ ERROR: Script recursion detected! Aborting to prevent infinite loop."
    exit 1
fi
export SCRIPT_RECURSIVE_GUARD="true"

DEFAULT_PORT="3000"  # Web app port (matches vite.config.ts)
DEV_COMMAND="bun run dev"  # Change this to your preferred command
AUTO_OPEN_BROWSER="true"  # Set to "false" to disable auto-opening browser

# Detect package manager and command - check actual package.json scripts
detect_dev_command() {
    # Check if package.json has a dev script and what it contains
    if [[ -f "package.json" ]]; then
        local dev_script=$(cat package.json | grep -o '"dev":[^,}]*' | sed 's/"dev":[[:space:]]*"//' | sed 's/"$//')

        # If the dev script uses concurrently or doesn't accept ports, use it as-is
        if [[ "$dev_script" == *"concurrently"* ]] || [[ "$dev_script" == *"bun run dev:"* ]]; then
            echo "bun run dev"
            return
        fi

        # Special handling for Vite projects
        if [[ "$dev_script" == "vite" ]]; then
            if [[ -f "bun.lockb" ]] || [[ -f "bunfig.toml" ]]; then
                echo "bun x vite --force --port $DEFAULT_PORT"
            elif [[ -f "package-lock.json" ]]; then
                echo "npx vite --force --port $DEFAULT_PORT"
            elif [[ -f "yarn.lock" ]]; then
                echo "yarn vite -- --force --port $DEFAULT_PORT"
            elif [[ -f "pnpm-lock.yaml" ]]; then
                echo "pnpm vite -- --force --port $DEFAULT_PORT"
            else
                echo "npx vite --force --port $DEFAULT_PORT"
            fi
            return
        fi
    fi

    # Default detection with port support
    if [[ -f "bun.lockb" ]] || [[ -f "bunfig.toml" ]]; then
        echo "bun run dev -- --force --port $DEFAULT_PORT"
    elif [[ -f "package-lock.json" ]]; then
        echo "npm run dev -- --force --port $DEFAULT_PORT"
    elif [[ -f "yarn.lock" ]]; then
        echo "yarn dev -- --force --port $DEFAULT_PORT"
    elif [[ -f "pnpm-lock.yaml" ]]; then
        echo "pnpm dev -- --force --port $DEFAULT_PORT"
    else
        echo "$DEV_COMMAND"
    fi
}

# 🚨 AGGRESSIVE FORK BOMB PREVENTION (Enhanced)
check_existing_server() {
    local port="${1:-$DEFAULT_PORT}"
    local project="$PROJECT_NAME"

    print_info "🔍 Running aggressive fork bomb checks..."

    # 1. CRITICAL: Total process count check
    local total_processes=$(ps aux | wc -l | tr -d ' ')
    if [[ $total_processes -gt 1500 ]]; then
        print_error "🚨 SYSTEM OVERLOAD! Found $total_processes total processes"
        print_error "Possible fork bomb detected - EMERGENCY STOP"
        exit 1
    fi

    # 2. CRITICAL: Development process count check
    local dev_processes=$(ps aux | grep -E "(bun|npm|yarn|node).*dev" | grep -v grep | wc -l | tr -d ' ')
    if [[ $dev_processes -gt 20 ]]; then
        print_error "🚨 DEV PROCESS FORK BOMB! Found $dev_processes dev processes"
        print_error "Maximum allowed: 20, found: $dev_processes"
        print_info "Emergency cleanup required - run './run.sh emergency-clean'"
        exit 1
    fi

    # 3. CRITICAL: Specific package manager process limits
    local bun_processes=$(ps aux | grep -E "bun.*dev" | grep -v grep | wc -l | tr -d ' ')
    local node_processes=$(ps aux | grep -E "node.*run.*dev" | grep -v grep | wc -l | tr -d ' ')
    local workerd_processes=$(ps aux | grep "workerd serve" | grep -v grep | wc -l | tr -d ' ')

    if [[ $bun_processes -gt 5 ]]; then
        print_error "🚨 BUN FORK BOMB! Found $bun_processes bun dev processes (max: 5)"
        exit 1
    fi

    if [[ $node_processes -gt 10 ]]; then
        print_error "🚨 NODE FORK BOMB! Found $node_processes node dev processes (max: 10)"
        exit 1
    fi

    if [[ $workerd_processes -gt 3 ]]; then
        print_error "🚨 WORKERD FORK BOMB! Found $workerd_processes workerd processes (max: 3)"
        exit 1
    fi

    # 4. Port conflict detection
    if lsof -i ":$port" >/dev/null 2>&1; then
        print_warning "Port $port is in use - will force kill in clean mode"
        local port_procs=$(lsof -t -i ":$port" 2>/dev/null | wc -l | tr -d ' ')
        if [[ $port_procs -gt 3 ]]; then
            print_error "🚨 PORT OVERLOAD! Found $port_procs processes on port $port"
            exit 1
        fi
    fi

    # 5. Project-specific process check
    local project_processes=$(pgrep -f "run dev.*$project" 2>/dev/null | wc -l | tr -d ' ')
    if [[ $project_processes -gt 2 ]]; then
        print_error "🚨 PROJECT FORK BOMB! Found $project_processes processes for '$project'"
        print_info "Maximum allowed: 2, found: $project_processes"
        exit 1
    fi

    # 6. Memory usage check
    local memory_pressure=$(ps aux | awk '{sum += $4} END {print int(sum)}')
    if [[ $memory_pressure -gt 80 ]]; then
        print_warning "⚠️ High memory usage detected: ${memory_pressure}%"
        print_info "Consider reducing running processes before starting dev server"
    fi

    print_success "✅ All fork bomb checks passed - system is safe"
    return 0
}

# Kill project servers safely
kill_project_servers() {
    local project="$PROJECT_NAME"
    local port="${1:-$DEFAULT_PORT}"

    print_info "🛑 Stopping servers for project: $project"

    # Kill by project pattern
    pkill -f "run dev.*$project" 2>/dev/null || true

    # Kill by port if specified
    if [[ -n "${port:-}" ]]; then
        local pid=$(lsof -t -i ":$port" 2>/dev/null || true)
        if [[ -n "$pid" ]]; then
            kill "$pid" 2>/dev/null || true
            print_success "Killed process on port $port"
        fi
    fi

    sleep 1
    print_success "Cleanup complete"
}

# ═══════════════════════════════════════════════════════════
# 🎯 MAIN EPIC LAUNCHER LOGIC
# ═══════════════════════════════════════════════════════════

main() {
    local command="${1:-clean}"  # DEFAULT TO CLEAN MODE FOR SAFETY
    if [[ $# -gt 0 ]]; then
        shift
    fi

    # Epic banner every time
    print_epic_banner

    case "$command" in
        "start"|"dev")
            print_header "🚨 STARTING IN SAFETY MODE (auto-clean)"
            print_warning "⚡ Using --clean mode by default to prevent conflicts"

            # Force clean startup - no conflicts allowed
            local dev_command="${1:-$(detect_dev_command)}"
            local port="${2:-$DEFAULT_PORT}"

            print_warning "🛑 Force killing any existing servers on port $port..."

            # Kill everything on the port aggressively
            local pids=$(lsof -t -i ":$port" 2>/dev/null || true)
            if [[ -n "$pids" ]]; then
                echo "$pids" | xargs -r kill -9 2>/dev/null || true
                print_success "Killed processes: $pids"
            fi

            # Kill any dev processes for this project
            pkill -f "run dev.*${PWD##*/}" 2>/dev/null || true
            pkill -f "bun.*dev" 2>/dev/null || true

            # Extra safety - kill any process listening on our port
            sleep 1
            local remaining=$(lsof -t -i ":$port" 2>/dev/null || true)
            if [[ -n "$remaining" ]]; then
                echo "$remaining" | xargs -r kill -9 2>/dev/null || true
            fi

            print_success "🧹 Auto-clean completed!"
            sleep 1

            print_info "Using command: $dev_command"
            print_info "Expected port: $port"
            ;;

        ""|"clean")
            print_header "🧹 FORCE CLEAN RESTART (DEFAULT MODE)"

            # Auto-detect dev command for clean mode
            local dev_command="${1:-$(detect_dev_command)}"
            local port="${2:-$DEFAULT_PORT}"

            print_warning "🛑 Force killing all servers on port $port..."

            # Kill everything on the port aggressively
            local pids=$(lsof -t -i ":$port" 2>/dev/null || true)
            if [[ -n "$pids" ]]; then
                echo "$pids" | xargs -r kill -9 2>/dev/null || true
                print_success "Killed processes: $pids"
            fi

            # Kill any dev processes for this project
            pkill -f "run dev.*${PWD##*/}" 2>/dev/null || true
            pkill -f "bun.*dev" 2>/dev/null || true

            # Extra safety - kill any process listening on our port
            sleep 1
            local remaining=$(lsof -t -i ":$port" 2>/dev/null || true)
            if [[ -n "$remaining" ]]; then
                echo "$remaining" | xargs -r kill -9 2>/dev/null || true
            fi

            print_success "🧹 Clean slate achieved!"
            sleep 1

            # Start fresh
            print_header "🚀 STARTING FRESH SERVER"
            # Check if this is a monorepo setup
            if [[ "$dev_command" == "bun run dev" ]] && [[ "$port" == "$DEFAULT_PORT" ]]; then
                print_success "Starting clean development servers..."
                print_info "🌐 Opening web app at http://localhost:$port"
                open_browser "$port"
            else
                print_success "Starting clean dev server on port $port..."
                # Open browser after delay
                open_browser "$port"
            fi

            echo -e "${SUCCESS}🎉 Fresh start! Welcome to clean development! 🎉${NC}"

            if [[ "$dev_command" == "bun run dev" ]] && [[ "$port" == "$DEFAULT_PORT" ]]; then
                echo -e "${INFO}📝 Multiple services starting - check console output for ports${NC}"
            else
                echo -e "${INFO}📱 Server: http://localhost:$port${NC}"
            fi
            echo -e "${WARNING}⚡ Press Ctrl+C to stop the server${NC}"
            echo ""

            # Execute with proper command handling
            if [[ "$dev_command" == *" "* ]]; then
                exec bash -c "$dev_command"
            else
                exec "$dev_command"
            fi
            ;;

        "stop")
            print_header "🛑 SHUTDOWN SEQUENCE"
            local port="${1:-$DEFAULT_PORT}"
            kill_project_servers "$port"
            ;;

        "restart")
            print_header "♻️ RESTART SEQUENCE"
            local dev_command="${1:-$(detect_dev_command)}"
            local port="${2:-$DEFAULT_PORT}"

            kill_project_servers "$port"
            sleep 2

            if check_existing_server "$port"; then
                print_success "🎉 Restarting with epic style..."
                
                # Check if this is a monorepo setup
                if [[ "$dev_command" == "bun run dev" ]] && [[ "$port" == "$DEFAULT_PORT" ]]; then
                    print_info "🌐 Opening web app at http://localhost:$port"
                    open_browser "$port"
                else
                    # Open browser after delay
                    open_browser "$port"
                    echo -e "${INFO}📱 Server: http://localhost:$port${NC}"
                fi
                
                echo -e "${WARNING}⚡ Press Ctrl+C to stop the server${NC}"
                echo ""
                
                # Properly execute command with arguments separated
                if [[ "$dev_command" == *" "* ]]; then
                    exec bash -c "$dev_command"
                else
                    exec "$dev_command"
                fi
            else
                print_error "Cannot restart - port still in use"
                exit 1
            fi
            ;;

        "emergency-clean")
            print_header "🚨 EMERGENCY FORK BOMB CLEANUP"
            print_error "⚠️ AGGRESSIVE CLEANUP MODE - USE ONLY IN EMERGENCIES"

            # Kill all development processes aggressively
            print_info "🛑 Killing all dev processes..."
            pkill -f "bun.*dev" 2>/dev/null || true
            pkill -f "npm.*dev" 2>/dev/null || true
            pkill -f "yarn.*dev" 2>/dev/null || true
            pkill -f "node.*dev" 2>/dev/null || true
            pkill -f "workerd serve" 2>/dev/null || true
            pkill -f "vite" 2>/dev/null || true
            pkill -f "wrangler.*dev" 2>/dev/null || true

            # Kill processes on common dev ports
            for port in 3000 3001 5173 5174 8080 8787; do
                local pids=$(lsof -t -i ":$port" 2>/dev/null || true)
                if [[ -n "$pids" ]]; then
                    echo "$pids" | xargs -r kill -9 2>/dev/null || true
                    print_success "Cleaned port $port"
                fi
            done

            sleep 2

            # Verify cleanup
            local remaining_dev=$(ps aux | grep -E "(bun|npm|yarn|node).*dev" | grep -v grep | wc -l | tr -d ' ')
            if [[ $remaining_dev -eq 0 ]]; then
                print_success "🎉 Emergency cleanup completed - system is clean"
            else
                print_warning "⚠️ $remaining_dev dev processes still running"
                print_info "Consider manual cleanup or system restart"
            fi
            ;;

        "status")
            print_header "📊 PROJECT STATUS DASHBOARD"

            local running_servers=$(ps aux | grep -E "(bun|npm|yarn) run dev" | grep -v grep | wc -l | tr -d ' ')
            local total_node_processes=$(ps aux | grep -E "(bun|node)" | grep -v grep | wc -l | tr -d ' ')

            print_info "Total dev servers running: $running_servers"
            print_info "Total node/bun processes: $total_node_processes"

            # Fork bomb warning
            if [[ $running_servers -gt 10 ]]; then
                print_error "🚨 POSSIBLE FORK BOMB! Too many dev servers running"
                print_info "Run './run.sh emergency-clean' to clean up"
            elif [[ $running_servers -gt 5 ]]; then
                print_warning "⚠️ High number of dev servers - consider cleanup"
            fi

            if [[ $running_servers -gt 0 ]]; then
                echo
                print_info "🔍 Running dev servers:"
                ps aux | grep -E "(bun|npm|yarn) run dev" | grep -v grep
            fi

            echo
            print_info "🌐 Port status:"
            for port in $DEFAULT_PORT 3000 3001 5173 5174 8080; do
                if lsof -i ":$port" >/dev/null 2>&1; then
                    if [[ $port -eq $DEFAULT_PORT ]]; then
                        echo -e "  ${ERROR}●${NC} Port $port: OCCUPIED (PROJECT PORT)"
                    else
                        echo -e "  ${ERROR}●${NC} Port $port: OCCUPIED"
                    fi
                else
                    if [[ $port -eq $DEFAULT_PORT ]]; then
                        echo -e "  ${SUCCESS}●${NC} Port $port: FREE (PROJECT PORT)"
                    else
                        echo -e "  ${SUCCESS}●${NC} Port $port: FREE"
                    fi
                fi
            done
            ;;

        "--test"|"test")
            print_header "🧪 COMPREHENSIVE TEST SUITE"

            local test_type="${1:-all}"
            local exit_code=0

            print_info "🔍 Running comprehensive test suite..."
            print_info "Test type: $test_type"
            echo ""

            # Create test results directory
            mkdir -p test-results
            local timestamp=$(date '+%Y%m%d_%H%M%S')
            local results_file="test-results/test_$timestamp.log"

            # Start test log
            {
                echo "🧪 COMPREHENSIVE TEST RESULTS - $timestamp"
                echo "Project: $PROJECT_NAME"
                echo "Working Directory: $(pwd)"
                echo "=========================================="
                echo ""
            } > "$results_file"

            # Test function helper
            run_test_section() {
                local section_name="$1"
                local test_command="$2"
                local required="${3:-false}"

                print_info "🔬 Testing: $section_name"
                echo "Testing: $section_name" >> "$results_file"

                if eval "$test_command" >> "$results_file" 2>&1; then
                    print_success "$section_name: PASSED ✅"
                    echo "Result: PASSED ✅" >> "$results_file"
                else
                    local test_exit=$?
                    print_error "$section_name: FAILED ❌"
                    echo "Result: FAILED ❌ (exit code: $test_exit)" >> "$results_file"

                    if [[ "$required" == "true" ]]; then
                        exit_code=1
                    fi
                fi
                echo "" >> "$results_file"
            }

            # 1. Environment and Dependencies Test
            if [[ "$test_type" == "all" ]] || [[ "$test_type" == "env" ]]; then
                print_header "🌍 ENVIRONMENT TESTS"

                run_test_section "Node.js Installation" "node --version"
                run_test_section "Package Manager (bun)" "bun --version"
                run_test_section "Package Manager (npm)" "npm --version"
                run_test_section "Git Installation" "git --version"

                if [[ -f "package.json" ]]; then
                    run_test_section "Package.json Validation" "node -e 'JSON.parse(require(\"fs\").readFileSync(\"package.json\", \"utf8\"))'"
                    run_test_section "Dependencies Check" "bun install --dry-run" "true"
                fi
            fi

            # 2. Project Structure Test
            if [[ "$test_type" == "all" ]] || [[ "$test_type" == "structure" ]]; then
                print_header "🏗️ PROJECT STRUCTURE TESTS"

                # Check for essential files
                run_test_section "Package.json exists" "test -f package.json" "true"
                run_test_section "Source directory exists" "test -d packages || test -d src" "true"
                run_test_section "Lockfile exists" "test -f bun.lock || test -f bun.lockb || test -f package-lock.json || test -f yarn.lock"

                # Check for configuration files
                run_test_section "TypeScript config" "test -f tsconfig.json || find packages -name 'tsconfig.json' -type f | grep -q ."
                run_test_section "Vite config" "test -f vite.config.ts || find packages -name 'vite.config.ts' -type f | grep -q ."

                # Check monorepo structure if applicable
                if [[ -d "packages" ]]; then
                    run_test_section "Monorepo packages" "find packages -name package.json | wc -l | grep -q '[1-9]'"
                fi
            fi

            # 3. Build and Compilation Tests
            if [[ "$test_type" == "all" ]] || [[ "$test_type" == "build" ]]; then
                print_header "🔧 BUILD TESTS"

                # TypeScript compilation
                if [[ -f "tsconfig.json" ]] || find packages -name "tsconfig.json" 2>/dev/null | grep -q .; then
                    if command -v tsc >/dev/null 2>&1; then
                        run_test_section "TypeScript compilation" "tsc --noEmit" "true"
                    elif [[ -f "bun.lock" ]] || [[ -f "bun.lockb" ]]; then
                        run_test_section "TypeScript compilation (bun)" "bun run build:types || bun tsc --noEmit || echo 'No TypeScript build script found'"
                    fi
                fi

                # Build tests
                if grep -q '"build"' package.json 2>/dev/null; then
                    run_test_section "Production build" "bun run build" "true"
                elif [[ -f "packages/web/package.json" ]] && grep -q '"build"' packages/web/package.json; then
                    run_test_section "Web package build" "cd packages/web && bun run build"
                fi

                # Check for build artifacts
                run_test_section "Build artifacts created" "test -d dist || test -d build || test -d packages/*/dist || test -d packages/*/build"
            fi

            # 4. Linting and Code Quality Tests
            if [[ "$test_type" == "all" ]] || [[ "$test_type" == "lint" ]]; then
                print_header "🔍 CODE QUALITY TESTS"

                # ESLint
                if grep -q '"lint"' package.json 2>/dev/null; then
                    run_test_section "ESLint checks" "bun run lint"
                fi

                # Prettier
                if grep -q '"format"' package.json 2>/dev/null; then
                    run_test_section "Code formatting" "bun run format:check || bun run format --check || echo 'No format check script'"
                fi

                # Type checking
                if grep -q '"type-check"' package.json 2>/dev/null; then
                    run_test_section "Type checking" "bun run type-check"
                fi
            fi

            # 5. Unit and Integration Tests
            if [[ "$test_type" == "all" ]] || [[ "$test_type" == "unit" ]]; then
                print_header "🧪 UNIT & INTEGRATION TESTS"

                # Check for test files
                if find . -name "*.test.ts" -o -name "*.test.js" -o -name "*.spec.ts" -o -name "*.spec.js" | grep -q .; then
                    run_test_section "Test files found" "find . -name '*.test.*' -o -name '*.spec.*' | head -5"

                    # Run tests based on available test runner
                    if grep -q '"test"' package.json 2>/dev/null; then
                        run_test_section "Unit tests" "bun run test" "true"
                    elif [[ -f "vitest.config.ts" ]] || [[ -f "vite.config.ts" ]]; then
                        run_test_section "Vitest tests" "bun test" "true"
                    elif command -v jest >/dev/null 2>&1; then
                        run_test_section "Jest tests" "jest"
                    fi
                else
                    print_warning "No test files found - creating basic test structure"
                    mkdir -p test
                    cat > test/basic.test.js << 'TESTEOF'
// Basic environment test
const assert = require('assert');

describe('Environment', () => {
    it('should have Node.js working', () => {
        assert(process.version);
        console.log('✅ Node.js version:', process.version);
    });

    it('should have proper working directory', () => {
        assert(process.cwd());
        console.log('✅ Working directory:', process.cwd());
    });
});
TESTEOF
                    run_test_section "Basic environment test" "node test/basic.test.js"
                fi
            fi

            # 6. Server and Port Tests
            if [[ "$test_type" == "all" ]] || [[ "$test_type" == "server" ]]; then
                print_header "🌐 SERVER TESTS"

                # Check port availability
                run_test_section "Default port ($DEFAULT_PORT) available" "! lsof -i :$DEFAULT_PORT"
                run_test_section "No conflicting dev processes" "! pgrep -f 'run dev.*$PROJECT_NAME'"

                # Test dev server startup (quick test)
                if [[ "$test_type" == "server" ]]; then
                    print_info "🚀 Testing dev server startup (5-second test)..."
                    local dev_cmd=$(detect_dev_command)

                    # Start server in background
                    timeout 5 bash -c "$dev_cmd" &
                    local server_pid=$!

                    sleep 3

                    if kill -0 $server_pid 2>/dev/null; then
                        run_test_section "Dev server starts successfully" "true"
                        kill $server_pid 2>/dev/null || true
                    else
                        run_test_section "Dev server starts successfully" "false" "true"
                    fi
                fi
            fi

            # 7. Git and Version Control Tests
            if [[ "$test_type" == "all" ]] || [[ "$test_type" == "git" ]]; then
                print_header "📝 VERSION CONTROL TESTS"

                run_test_section "Git repository" "test -d .git"
                run_test_section "Git status clean" "git status --porcelain | wc -l | grep -q '^0$' || echo 'Working directory has changes'"
                run_test_section "No merge conflicts" "! git status | grep -q 'Unmerged paths'"

                if git remote >/dev/null 2>&1; then
                    run_test_section "Remote repository accessible" "git ls-remote --heads origin >/dev/null"
                fi
            fi

            # 8. Security and Dependency Tests
            if [[ "$test_type" == "all" ]] || [[ "$test_type" == "security" ]]; then
                print_header "🔒 SECURITY TESTS"

                # Check for security vulnerabilities
                if command -v bun >/dev/null 2>&1; then
                    run_test_section "Dependency security audit" "bun audit || echo 'No security issues found'"
                fi

                # Check for sensitive files
                run_test_section "No secrets in git" "! git log --all --full-history -- '*.env' '*.key' '*.pem' | grep -q commit"
                run_test_section "Gitignore exists" "test -f .gitignore"

                # Check environment files
                if [[ -f ".env" ]]; then
                    run_test_section ".env not in git" "git ls-files --error-unmatch .env 2>/dev/null && false || true"
                fi
            fi

            # Generate final report
            print_header "📊 TEST RESULTS SUMMARY"

            local total_tests=$(grep -c "Testing:" "$results_file")
            local passed_tests=$(grep -c "Result: PASSED" "$results_file")
            local failed_tests=$(grep -c "Result: FAILED" "$results_file")

            {
                echo ""
                echo "=========================================="
                echo "FINAL SUMMARY:"
                echo "Total Tests: $total_tests"
                echo "Passed: $passed_tests"
                echo "Failed: $failed_tests"
                echo "Success Rate: $(( passed_tests * 100 / total_tests ))%"
                echo "=========================================="
            } >> "$results_file"

            print_info "📋 Total tests: $total_tests"
            print_success "✅ Passed: $passed_tests"

            if [[ $failed_tests -gt 0 ]]; then
                print_error "❌ Failed: $failed_tests"
            fi

            local success_rate=$(( passed_tests * 100 / total_tests ))
            if [[ $success_rate -ge 90 ]]; then
                print_success "🎉 Excellent! Success rate: ${success_rate}%"
            elif [[ $success_rate -ge 70 ]]; then
                print_warning "⚠️ Good but needs improvement: ${success_rate}%"
            else
                print_error "🚨 Critical issues found: ${success_rate}%"
                exit_code=1
            fi

            print_info "📄 Detailed results saved to: $results_file"
            echo ""
            print_info "💡 Test specific areas with:"
            echo "  $0 --test env       # Environment only"
            echo "  $0 --test build     # Build tests only"
            echo "  $0 --test server    # Server tests only"
            echo "  $0 --test security  # Security audit"

            exit $exit_code
            ;;

        "help"|"-h"|"--help")
            print_header "🎯 EPIC COMMAND REFERENCE"
            cat << EOF
${BOLD}Usage:${NC} $0 [COMMAND] [OPTIONS]

${BOLD}🚨 DEFAULT SAFETY MODE: --clean${NC}
Running '$0' with no arguments defaults to --clean mode for fork bomb prevention.

${BOLD}Commands:${NC}
  ${SUCCESS}(no args), clean${NC}   🛡️ Clean restart (DEFAULT - kills conflicts first)
  ${WARNING}start, dev${NC}         ⚠️ Start with safety checks (may fail if conflicts)
  ${WARNING}stop${NC}              Stop dev server for this project
  ${INFO}restart${NC}           Restart dev server with safety checks
  ${ERROR}emergency-clean${NC}    🚨 EMERGENCY: Kill ALL dev processes system-wide
  ${INFO}status${NC}            Show running dev servers & fork bomb detection
  ${SUCCESS}--test, test${NC}      Run comprehensive test suite
  ${INFO}help${NC}              Show this epic help

${BOLD}🚨 Fork Bomb Prevention:${NC}
  • Aggressive process count monitoring
  • Automatic cleanup of duplicate servers
  • Emergency detection and response
  • System resource limit enforcement

${BOLD}Test Options:${NC}
  ${SUCCESS}--test${NC}            Run all tests (comprehensive)
  ${SUCCESS}--test env${NC}        Environment & dependencies only
  ${SUCCESS}--test structure${NC}  Project structure validation
  ${SUCCESS}--test build${NC}      Build & compilation tests
  ${SUCCESS}--test lint${NC}       Code quality & linting
  ${SUCCESS}--test unit${NC}       Unit & integration tests
  ${SUCCESS}--test server${NC}     Server startup & port tests
  ${SUCCESS}--test git${NC}        Git & version control tests
  ${SUCCESS}--test security${NC}   Security audit & dependency check

${BOLD}Examples:${NC}
  $0                     # 🛡️ Clean restart (DEFAULT - safest option)
  $0 start               # Start with safety checks (may fail)
  $0 emergency-clean     # 🚨 Kill ALL dev processes (emergency only)
  $0 status              # Check for fork bombs
  $0 --test              # Run full comprehensive test suite

${BOLD}🛡️ Safety Features:${NC}
  • DEFAULT --clean mode prevents fork bombs
  • Aggressive process monitoring (max 20 dev processes)
  • Port conflict detection and cleanup
  • Memory usage monitoring
  • Emergency cleanup command
  • Browser auto-opening (disable with AUTO_OPEN_BROWSER="false")

${BOLD}🚨 Emergency Situations:${NC}
  • High CPU usage: Run '$0 emergency-clean'
  • Too many processes: Use '$0 status' to detect
  • System hangs: Force quit and run emergency-clean
  • Fork bomb detected: Automatic prevention and cleanup

${BOLD}🎯 Pro Tips:${NC}
  • ALWAYS use '$0' (clean mode) for safety
  • Avoid direct 'bun dev' commands - use scripts/run.sh only
  • Monitor with '$0 status' regularly
  • Emergency cleanup available for critical situations
EOF
            ;;

        *)
            print_error "Unknown command: $command"
            print_info "Use '$0 help' for epic command reference"
            exit 1
            ;;
    esac
}

# ═══════════════════════════════════════════════════════════
# 🚀 EPIC EXECUTION
# ═══════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════
# 🚨 IMMEDIATE PORT CHECK - PREVENT DUPLICATE RUNS
# ═══════════════════════════════════════════════════════════

# For default start command, check port immediately before doing ANYTHING
if [[ $# -eq 0 ]] || [[ "${1:-}" == "start" ]] || [[ "${1:-}" == "dev" ]] || [[ "${1:-}" == "" ]]; then
    # Quick port check - no fancy output, just exit if busy
    if lsof -i ":$DEFAULT_PORT" >/dev/null 2>&1; then
        echo "❌ Port $DEFAULT_PORT already in use - server likely running"
        echo "💡 Use './scripts/run.sh status' to check or './scripts/run.sh stop' to stop"
        echo "🧹 Use './scripts/run.sh --clean' to force stop and restart fresh"
        exit 1
    fi
    
    # Quick process check for this project
    if pgrep -f "run dev.*${PWD##*/}" >/dev/null 2>&1; then
        echo "❌ Dev server for '${PWD##*/}' already running"
        echo "💡 Use './scripts/run.sh status' to check or './scripts/run.sh stop' to stop"
        echo "🧹 Use './scripts/run.sh --clean' to force stop and restart fresh"
        exit 1
    fi
fi

# Safely handle arguments - prevent infinite recursion
if [[ $# -eq 0 ]]; then
    main "clean"
else
    main "$@"
fi
